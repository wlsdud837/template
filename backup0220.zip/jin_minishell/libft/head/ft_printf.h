/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 16:03:39 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 20:58:22 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include <stdlib.h>
# include <unistd.h>
# include "libft.h"

typedef struct	s_printf
{
	char		flag;
	int			w;
	int			dec;
	char		sp;
	char		*data;
}				t_printf;

int				ft_printf(int fd, const char *str, ...);

char			*ft_itoa_unsigned(unsigned int n);
char			*ft_itoa_base_unhex(unsigned long val);
char			*ft_itoa_unhex(unsigned int val);

int				sep(const char *str, t_printf *io, va_list *ap);

int				pd(t_printf *io, va_list *ap);
int				char_data(t_printf *io, va_list *ap);
int				string_data(t_printf *io, va_list *ap);
int				npercent(t_printf *io);
int				pointer_data(t_printf *io, va_list *ap);
int				low_hex_data(t_printf *io, va_list *ap);
int				upper_hex_data(t_printf *io, va_list *ap);
int				demical_data(t_printf *io, va_list *ap);
int				u_demical_data(t_printf *io, va_list *ap);

int				print_data(int fd, t_printf *io);
void			w_space(int fd, char str, int cnt);
int				print_c(int fd, t_printf *io);
int				print_str(int fd, t_printf *io);
int				print_pt(int fd, t_printf *io);
int				print_per(int fd, t_printf *io);
int				print_num(int fd, t_printf *io);

void			init_(t_printf *io);
int				print_data_and_free(t_printf *io);

#endif
