/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_str.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 20:10:13 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/25 21:51:32 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void		w_space(int fd, char str, int cnt)
{
	if (str == 0)
		str = ' ';
	while (cnt > 0)
	{
		write(fd, &str, 1);
		cnt--;
	}
}

int			print_c(int fd, t_printf *io)
{
	if (io->flag == '-')
	{
		write(fd, io->data, 1);
		w_space(fd, ' ', io->w - 1);
	}
	else
	{
		w_space(fd, ' ', io->w - 1);
		write(fd, io->data, 1);
	}
	return (io->w > 0 ? io->w : 1);
}

int			print_str(int fd, t_printf *io)
{
	int		d_size;
	int		p_len;

	d_size = ft_strlen(io->data);
	if (io->dec == -1)
		p_len = d_size;
	else
		p_len = io->dec < d_size ? io->dec : d_size;
	if (io->flag == '-')
	{
		write(fd, io->data, p_len);
		w_space(fd, ' ', io->w - p_len);
	}
	else
	{
		w_space(fd, ' ', io->w - p_len);
		write(fd, io->data, p_len);
	}
	return (io->w > p_len ? io->w : p_len);
}

int			print_pt(int fd, t_printf *io)
{
	int		p_len;

	p_len = ft_strlen(io->data);
	if (io->dec == 0 && p_len == 3 && io->data[2] == '0')
		p_len -= 1;
	if (io->flag == '-')
	{
		write(fd, io->data, p_len);
		w_space(fd, ' ', io->w - p_len);
	}
	else
	{
		w_space(fd, ' ', io->w - p_len);
		write(fd, io->data, p_len);
	}
	return (io->w > p_len ? io->w : p_len);
}

int			print_per(int fd, t_printf *io)
{
	char	p;

	p = '%';
	if (io->flag == '-')
	{
		write(fd, &p, 1);
		w_space(fd, ' ', io->w - 1);
	}
	else
	{
		w_space(fd, io->flag, io->w - 1);
		write(fd, &p, 1);
	}
	return (io->w > 0 ? io->w : 1);
}
