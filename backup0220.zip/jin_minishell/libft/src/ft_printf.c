/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 16:31:44 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 20:49:36 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int				print_data(int fd, t_printf *io)
{
	if (io->sp == 'x' || io->sp == 'X' || io->sp == 'u'
	|| io->sp == 'd' || io->sp == 'i')
		return (print_num(fd, io));
	if (io->sp == '%')
		return (print_per(fd, io));
	if (io->sp == 'c')
		return (print_c(fd, io));
	if (io->sp == 's')
		return (print_str(fd, io));
	if (io->sp == 'p')
		return (print_pt(fd, io));
	return (-1);
}

void			init_(t_printf *io)
{
	size_t i;

	i = 0;
	free(io->data);
	while (i < sizeof(*io))
	{
		((unsigned char *)io)[i] = 0;
		i++;
	}
}

int				ft_printf(int fd, const char *str, ...)
{
	t_printf		io;
	size_t			cnt;
	int				index;
	int				i;
	va_list			ap;

	cnt = 0;
	i = 0;
	va_start(ap, str);
	while (str[i])
	{
		if (str[i] != '%')
		{
			write(fd, &str[i++], 1);
			cnt++;
			continue ;
		}
		if ((index = sep(&str[i], &io, &ap)) == -1 || !pd(&io, &ap))
			return (-1);
		i += index;
		cnt += print_data(fd, &io);
		init_(&io);
	}
	va_end(ap);
	return (cnt);
}
