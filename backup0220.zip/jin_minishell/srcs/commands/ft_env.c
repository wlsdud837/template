/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_env.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 16:38:36 by jinylee           #+#    #+#             */
/*   Updated: 2021/02/20 16:38:37 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minishell.h"

void	ft_add_env_export_dollar(t_shell *shell, char *str)
{
	char	*str_env;

	if (!(str_env = ft_strdup(str)) || !add_lst_to_free(shell, str_env))
		ft_exit_failure(shell, F_MALLOC, str_env);
	replace_env_content(shell, "_", str_env, TO_PRINT);
}

int		ft_env(t_shell *shell, char **exec_args, char **tab_env)
{
	(void)exec_args;
	(void)tab_env;
	ft_add_env_export_dollar(shell, "env");
	ft_print_env_var(shell->var_env);
	return (SUCCESS);
}
