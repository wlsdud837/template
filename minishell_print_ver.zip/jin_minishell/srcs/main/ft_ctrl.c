/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ctrl.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@42seoul.kr>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 16:33:59 by jinylee           #+#    #+#             */
/*   Updated: 2021/02/20 16:34:08 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minishell.h"

void	ft_ctrl_c(int sign)
{
	char	c;

	ft_printf(1, "\b\b  \b\b");
	(void)sign;
	c = '\n';
	write(1, &c, 1);
	print_header(g_shell->std[2]);
}

void	ft_ctrl_back(int sign)
{
	ft_printf(1, "Quit: %d\n", sign);
}
