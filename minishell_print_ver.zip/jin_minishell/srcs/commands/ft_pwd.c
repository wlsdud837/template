/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pwd.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 16:38:48 by jinylee           #+#    #+#             */
/*   Updated: 2021/02/20 16:38:50 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minishell.h"

int		ft_pwd(t_shell *shell, char **exec_args, char **tab_env)
{
	int		res;
	char	*path_var;
	char	*path_cwd;

	(void)exec_args;
	(void)tab_env;
	res = SUCCESS;
	path_cwd = NULL;
	if (get_var_env(shell, "PWD", &path_var, 1) && path_var &&
		!ft_strncmp(path_var, "//", 2))
		res = ft_printf(STDOUT_FILENO, "%s\n", path_var);
	else
	{
		if (!(path_cwd = getcwd(NULL, 0)))
			ft_exit_failure(shell, F_MALLOC, NULL);
		res = ft_printf(STDOUT_FILENO, "%s\n", path_cwd);
	}
	ft_free_ptr(path_cwd);
	shell->exit = 0;
	return (res);
}
