/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_seperate.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 19:37:48 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 20:47:08 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	get_f(const char *s, t_printf *io)
{
	size_t	i;

	i = 0;
	if (s[i] == '0' || s[i] == '-')
	{
		io->flag = s[i];
		i++;
		while (s[i] == '0' || s[i] == '-')
		{
			if (s[i++] == '-')
				io->flag = '-';
		}
		return (i);
	}
	io->flag = 0;
	return (0);
}

int	get_w(const char *s, t_printf *io, va_list *ap)
{
	size_t	i;

	i = 0;
	if (s[i] == '*')
	{
		io->w = va_arg(*ap, int);
		if (io->w < 0)
		{
			io->w *= -1;
			io->flag = '-';
		}
		i++;
		return (i);
	}
	io->w = ft_atoi(&s[i]);
	while (s[i] >= '0' && s[i] <= '9')
		i++;
	return (i);
}

int	div_pre(const char *s, t_printf *io, va_list *ap)
{
	size_t	i;

	i = 0;
	if (s[i] != '.')
	{
		io->dec = -1;
		return (0);
	}
	i++;
	if (s[i] == '*')
	{
		io->dec = va_arg(*ap, int);
		if (io->dec < 0)
			io->dec = -1;
		i++;
		return (i);
	}
	io->dec = ft_atoi(&s[i]);
	while (s[i] >= '0' && s[i] <= '9')
		i++;
	return (i);
}

int	div_sp(const char *s, t_printf *io)
{
	size_t	i;

	i = 0;
	if (s[i] == 'c' || s[i] == 's' || s[i] == 'p'
		|| s[i] == 'd' || s[i] == 'i' || s[i] == 'u'
			|| s[i] == 'x' || s[i] == 'X' || s[i] == '%')
	{
		io->sp = s[i];
		return (1);
	}
	io->sp = '\0';
	return (0);
}

int	sep(const char *s, t_printf *io, va_list *ap)
{
	int	index;
	int sp;

	index = 1;
	index += get_f(&s[index], io);
	index += get_w(&s[index], io, ap);
	index += div_pre(&s[index], io, ap);
	if (!(sp = div_sp(&s[index], io)))
		return (-1);
	index += sp;
	return (index);
}
