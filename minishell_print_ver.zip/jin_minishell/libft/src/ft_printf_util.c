/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_util.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 19:33:07 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 21:03:19 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

size_t		get_hex_len(unsigned long val, int base)
{
	size_t len;

	len = 0;
	if (val == 0)
		return (1);
	while (val)
	{
		val /= base;
		len++;
	}
	return (len);
}

char		*ft_itoa_unsigned(unsigned int n)
{
	char	*base;
	size_t	len;
	char	*res;

	base = "0123456789";
	len = get_hex_len(n, 10);
	if ((res = (char *)malloc(sizeof(char) * (len + 1))) == 0)
		return (0);
	res[len] = 0;
	while (len > 0)
	{
		res[--len] = base[(n % 10)];
		n /= 10;
	}
	return (res);
}

char		*ft_itoa_base_unhex(unsigned long val)
{
	char	*base;
	size_t	len;
	char	*res;

	base = "0123456789abcdef";
	len = get_hex_len(val, 16);
	if ((res = (char *)malloc(sizeof(char) * (len + 1))) == 0)
		return (0);
	res[len] = 0;
	while (len > 0)
	{
		res[--len] = base[(val % 16)];
		val /= 16;
	}
	return (res);
}

char		*ft_itoa_unhex(unsigned int val)
{
	char	*base;
	size_t	len;
	char	*res;

	base = "0123456789abcdef";
	len = get_hex_len(val, 16);
	res = (char *)malloc(sizeof(char) * (len + 1));
	if (res == 0)
		return (0);
	res[len] = 0;
	while (len > 0)
	{
		res[--len] = base[(val % 16)];
		val /= 16;
	}
	return (res);
}
