/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_make_str.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 19:52:26 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 21:00:53 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int			char_data(t_printf *io, va_list *ap)
{
	io->data = (char *)malloc(sizeof(char) * 2);
	if (io->data == 0)
		return (0);
	io->data[0] = va_arg(*ap, int);
	io->data[1] = 0;
	return (1);
}

int			string_data(t_printf *io, va_list *ap)
{
	char	*tmp;
	size_t	len;

	tmp = va_arg(*ap, char *);
	if (tmp == 0)
	{
		io->data = (char *)malloc(sizeof(char) * 7);
		if (io->data == 0)
			return (0);
		ft_memcpy(io->data, "(null)", 6);
		io->data[6] = 0;
		return (1);
	}
	len = ft_strlen(tmp);
	io->data = (char *)malloc(sizeof(char) * (len + 1));
	if (io->data == 0)
		return (0);
	ft_memcpy(io->data, tmp, len);
	io->data[len] = '\0';
	return (1);
}

int			npercent(t_printf *io)
{
	io->data = (char *)malloc(sizeof(char) * 2);
	if (io->data == 0)
		return (0);
	io->data[0] = '%';
	io->data[1] = '\0';
	return (1);
}

int			pd(t_printf *io, va_list *ap)
{
	if ((io->sp == 'c' && !char_data(io, ap))
	|| (io->sp == 's' && !string_data(io, ap))
	|| (io->sp == 'p' && !pointer_data(io, ap))
	|| (io->sp == 'x' && !low_hex_data(io, ap))
	|| (io->sp == 'X' && !upper_hex_data(io, ap))
	|| (io->sp == 'd' && !demical_data(io, ap))
	|| (io->sp == 'i' && !demical_data(io, ap))
	|| (io->sp == 'u' && !u_demical_data(io, ap))
	|| (io->sp == '%' && !npercent(io)))
		return (0);
	return (1);
}
