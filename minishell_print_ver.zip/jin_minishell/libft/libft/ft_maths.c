/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_maths.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/20 16:47:21 by jinylee           #+#    #+#             */
/*   Updated: 2021/02/20 16:47:23 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int	ft_max(int x, int y)
{
	if (x >= y)
		return (x);
	return (y);
}

int	ft_min(int x, int y)
{
	if (x <= y)
		return (x);
	return (y);
}

int	ft_abs(int x)
{
	if (x < 0)
		return (-x);
	return (x);
}
