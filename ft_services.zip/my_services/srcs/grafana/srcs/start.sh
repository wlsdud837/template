#!/bin/sh

# Start Telegraf and Grafana server.
telegraf & grafana-server
