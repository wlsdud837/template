/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_num.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 20:05:10 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/24 21:02:19 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	g_max(int a, int b)
{
	return (a >= b ? a : b);
}

static void	not_decision(int fd, t_printf *io, int d_size, int len)
{
	if (io->flag == '-')
	{
		write(fd, io->data, d_size);
		w_space(fd, ' ', io->w - d_size);
	}
	else if (io->flag == '0')
	{
		write(fd, io->data, len);
		w_space(fd, '0', io->w - d_size);
		write(fd, io->data + len, d_size - len);
	}
	else if (io->flag == 0)
	{
		w_space(fd, ' ', io->w - d_size);
		write(fd, io->data, d_size);
	}
}

static void	ft_decision(int fd, t_printf *io, int d_size, int len)
{
	int	w;

	w = io->w - g_max(d_size, io->dec + len);
	if (io->flag == '-')
	{
		write(fd, io->data, len);
		w_space(fd, '0', io->dec - (d_size - len));
		write(fd, io->data + len, d_size - len);
		w_space(fd, ' ', w);
	}
	else
	{
		w_space(fd, ' ', w);
		write(fd, io->data, len);
		w_space(fd, '0', io->dec - (d_size - len));
		write(fd, io->data + len, d_size - len);
	}
}

int			print_num(int fd, t_printf *io)
{
	int		d_size;
	int		max;
	int		len;

	len = (io->data[0] == '-' ? 1 : 0);
	d_size = ft_strlen(io->data);
	if (io->dec == -1)
	{
		not_decision(fd, io, d_size, len);
	}
	else
	{
		if (io->dec == 0 && io->data[0] == '0' && d_size == 1)
			d_size = 0;
		ft_decision(fd ,io, d_size, len);
	}
	max = g_max(g_max(d_size, io->dec + len), io->w);
	return (max);
}
