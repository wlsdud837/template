/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_make_num.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jinylee <jinylee@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/24 19:45:31 by jinylee           #+#    #+#             */
/*   Updated: 2020/10/25 21:51:13 by jinylee          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int			pointer_data(t_printf *io, va_list *ap)
{
	unsigned long	tmp;
	char			*hex;
	size_t			len;

	tmp = (unsigned long)va_arg(*ap, void *);
	hex = ft_itoa_base_unhex(tmp);
	if (hex == 0)
		return (0);
	len = ft_strlen(hex);
	io->data = (char*)malloc(sizeof(char) * (len + 3));
	if (io->data == 0)
	{
		free(hex);
		return (0);
	}
	ft_memcpy(io->data + 2, hex, len);
	free(hex);
	io->data[0] = '0';
	io->data[1] = 'x';
	io->data[len + 2] = '\0';
	return (1);
}

int			low_hex_data(t_printf *io, va_list *ap)
{
	unsigned int	tmp;

	tmp = va_arg(*ap, unsigned int);
	io->data = ft_itoa_unhex(tmp);
	if (io->data == 0)
		return (0);
	return (1);
}

int			upper_hex_data(t_printf *io, va_list *ap)
{
	unsigned int	tmp;
	size_t			i;

	tmp = va_arg(*ap, unsigned int);
	if ((io->data = ft_itoa_unhex(tmp)) == NULL)
		return (0);
	i = 0;
	while (io->data[i] != '\0')
	{
		io->data[i] = ft_toupper(io->data[i]);
		i++;
	}
	return (1);
}

int			demical_data(t_printf *io, va_list *ap)
{
	int		tmp;

	tmp = va_arg(*ap, int);
	io->data = ft_itoa(tmp);
	if ((io->data) == NULL)
		return (0);
	return (1);
}

int			u_demical_data(t_printf *io, va_list *ap)
{
	unsigned int	tmp;

	tmp = va_arg(*ap, unsigned int);
	io->data = ft_itoa_unsigned(tmp);
	if ((io->data) == 0)
		return (0);
	return (1);
}
