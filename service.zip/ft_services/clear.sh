kubectl delete --all ingresses
kubectl delete --all deplyments
kubectl delete --all pods
kubectl delete --all services
kubectl delete -f https://raw.githubusercontent.com/metallb/metallb/v0.9.3/manifests/namespace.yaml
minikube stop;
minikube delete;
