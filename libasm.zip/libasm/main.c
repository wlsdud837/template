#include "libasm.h"

int     test_strlen(void)
{
    printf("\n");
    printf("******************************************\n");
    printf("*               test_strlen              *\n");
    printf("******************************************\n");
    char *a = "test_jinylee_strlen";
    char *b = "";
    char *d = "jinylee";

    // strlen (strlen segfaults with NULL pointer)
    printf("strlen:		%lu\nft_strlen:	%lu\n__\n",strlen(a), ft_strlen(a));
    printf("strlen:		%lu\nft_strlen:	%lu\n__\n",strlen(b), ft_strlen(b));
	printf("strlen:		%lu\nft_strlen:	%lu\n__\n",strlen(d), ft_strlen(d));

    return(0);
}

int     test_strcpy(void)
{

    printf("\n");
    printf("******************************************\n");
    printf("*               test_strcpy              *\n");
    printf("******************************************\n");
    char *a = "str_test_strcpy";
    char *b = "";
    char *d = "jinylee";
    char new_a[strlen(a) + 1];
	char ft_new_a[strlen(a) + 1];
	char new_b[strlen(b) + 1];
	char ft_new_b[strlen(b) + 1];
	char new_d[strlen(d) + 1];
	char ft_new_d[strlen(d) + 1];
    // char new_e[strlen(a) + 4];
	// char ft_new_e[strlen(a) + 4];
    // char new_f[strlen(a) - 8];
	// char ft_new_f[strlen(a) - 8];
	printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_a, a), ft_strcpy(ft_new_a, a));
	printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_b, b), ft_strcpy(ft_new_b, b));
	printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_d, d), ft_strcpy(ft_new_d, d));
    //printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_e, a), ft_strcpy(ft_new_e, a));
    //printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_f, a), ft_strcpy(ft_new_f, a));
    //printf("strcpy:		%s\nft_strcpy:	%s\n__\n",strcpy(new_f, d), ft_strcpy(ft_new_f, d));
    return(0);
}


int     test_strcmp(void)
{
    int a;
    printf("\n");
    printf("******************************************\n");
    printf("*               test_strcmp              *\n");
    printf("******************************************\n");
    printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("jinylee",""),ft_strcmp("jinylee",""));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("test_strcmp_jinylee_test","test_jinylee_strcmp_ss"),ft_strcmp("test_strcmp_jinylee_test","test_jinylee_strcmp_ss"));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("test_jinylee_strcmp_ss","test_jinylee_strcmp_ss"),ft_strcmp("test_jinylee_strcmp_ss","test_jinylee_strcmp_ss"));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("ho","ho"),ft_strcmp("ho","ho"));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("",""),ft_strcmp("",""));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("jinylee","ho"),ft_strcmp("jinylee","ho"));
	printf("strcmp:		%d\nft_strcmp:	%d\n__\n",a = strcmp("test_strcmp_jin","test_zjinylee_strcmp_ss"),ft_strcmp("test_strcmp_jin","test_zjinylee_strcmp_ss"));
	//printf("strcmp:		%d\nft_strcmp:	%d\n__\n",ft_strcmp(NULL, NULL),ft_strcmp(NULL, NULL));
    return(0);
}

int     test_strdup(void)
{
    printf("\n");
    printf("******************************************\n");
    printf("*               test_strdup              *\n");
    printf("******************************************\n");
    char *a = "test strdup jinylee";
    char *b = "";
    char *d = "jinylee";

    char *new_a = strdup(a);
    char *new_b = strdup(b);
    char *new_d = strdup(d);
    char *ft_new_a = ft_strdup(a);
    char *ft_new_b = ft_strdup(b);
    char *ft_new_d = ft_strdup(d);

    printf("strdup:		%s\nft_strdup:	%s\n__\n", new_a, ft_new_a);
    printf("strdup:		%s\nft_strdup:	%s\n__\n", new_b, ft_new_b);
    printf("strdup:		%s\nft_strdup:	%s\n__\n", new_d, ft_new_d);
    free(new_a);
    free(new_b);
    free(new_d);
    free(ft_new_a);
    free(ft_new_b);
    free(ft_new_d);

    return(0);
}

int     test_read(void)
{
    printf("\n");
    printf("******************************************\n");
    printf("*                test_read               *\n");
    printf("******************************************\n");
    int bufferlen = 50;
    int fd_1 = open("ft_write.s", O_RDONLY);
    int fd_ft_1 = open("ft_write.s", O_RDONLY);

    char buffer[bufferlen + 1];
    char ft_buffer[bufferlen + 1];
    buffer[bufferlen] = '\0';
    ft_buffer[bufferlen] = '\0';
    printf("read - %zd\n", read(fd_1, buffer, -5));
    printf("value of errno: %d\n", errno);
    printf("ft_read - %zd\n", ft_read(fd_ft_1, ft_buffer, -5));
    printf("value of errno: %d\n", errno);
    printf("read - %zd\n", read(fd_1, buffer, bufferlen));
    printf("ft_read - %zd\n", ft_read(fd_ft_1, ft_buffer, bufferlen));
    return(0);
}

int     test_write(void)
{
    printf("\n");
    printf("------------------------------------------\n");
    printf("*               test_write               *\n");
    printf("------------------------------------------\n");
    char *a = "test_write_test_write";
    char *b = "";
    char *c = NULL;
    char *d = "jinylee";

    printf("\n");
    printf("write a:    ");
    printf("\n");
    write(1, a, strlen(a));
    printf("\n");
    printf("ft_write a:    ");
    printf("\n");
    ft_write(1, a, strlen(a));
    printf("\n");
    printf("write b:    ");
    printf("\n");
    write(1, b, strlen(b));
    printf("\n");
    printf("ft_write b:    ");
    printf("\n");
    ft_write(1, b, strlen(b));
    printf("\n");
    printf("write c:    ");
    printf("\n");
    write(1, c, 0);
    printf("\n");
    printf("ft_write c:    ");
    printf("\n");
    ft_write(1, c, 0);
    printf("\n");
    printf("write d:    ");
    printf("\n");
    write(1, d, strlen(d));
    printf("\n");
    printf("ft_write d:    ");
    printf("\n");
    ft_write(1, d, strlen(d));
    printf("\n");
    return(0);
}

int     main(void)
{
    test_strlen();
    test_strcpy();
    test_strcmp();
    test_strdup();
    test_read();
    test_write();
    return(0);
}
